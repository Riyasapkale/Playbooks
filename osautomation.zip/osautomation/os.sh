#!/bin/bash
#//OS ISO Mount Automation Script
#//Vaiables: NFSSERVER,logfile,date,sessionid,token,imagetype,imageindex
#Configfile: IPMI IP file location where we mentioned console ip on wich we have to mount ISO 
#Logfle:$logfile
#Pre-requsite: we require curl package utility, Jq(JSON Processor) package utility is available through EPEL repository so to install jq we need to install EPEL repoaitory by using yum command after that we can install jq package.


#Author: Riya Sapkale
#*************************************


user='admin'
pass=`cat secret.txt | openssl enc -aes-256-cbc -md sha512 -a -d -salt -pass pass:Secret@123#`
NFSSERVER=10.157.214.223
logfile="oslogfile.$(date +'%Y-%m-%d')"
date=`date`
echo 'Running script on' $date >> $logfile
echo '' >> $logfile
echo "enter file Location where console IP is listed"
read filelocation

for n in $(cat $filelocation); do

#echo "preceding for os installtion on $n"

   echo 'preceding for os installtion on' $n  >> $logfile

# we are taking sessionID and and token & from first curl request
   curl -i --insecure --silent --location --request POST https://$n/api/session --form 'username='${user} --form 'password='${pass} | grep -e "Set" -e "CSRFToken" > token

   echo 'output of session first curl API....' >> $logfile 

   cat token >> $logfile
   echo '' >> $logfile 

   sessionid=`cat token | grep Set | cut -c 24-53`

   echo 'sessionid of first API response:' $sessionid >> $logfile 

   token=`cat token | gawk -F: '{ print $14 }' | gawk -F } '{ print $1 }' | cut -c 3-10`

   echo 'print token of first API response :' $token >>  $logfile 

#we are Enabeling virtual media in BMC & passing token and sessionid to below curl request
#echo "Enable Virtual Media in BMC....!"
   echo 'Enable Virtual Media in BMC....!' >> $logfile 
   echo 'Passing sessionid of first API to second curl request to enable Virtual Media in BMC : ' $sessionid >> $logfile
   echo 'Passing token of first API to second curl request to enable Virtual Media in BMC: ' $token >> $logfile

   curl  --insecure --silent --location --request PUT "https://$n/api/settings/media/general" --header "X-CSRFTOKEN: ${token//[$'\t\r\n ']}" --header 'content-type: application/json' --header "Cookie: QSESSIONID=${sessionid//[$'\t\r\n ']}" --data '{"local_media_support":0,"remote_media_support":1, "same_settings":1, "mount_cd":1, "mount_hd":1,"id":1,"cd_remote_server_address":"'$NFSSERVER'","cd_remote_source_path":"/nfs-data","cd_remote_share_type":"nfs","cd_error_code":0}' >> $logfile

#we are taking list of ISO images from NFS Server in below curl request
   echo " "
#echo  "Get list of images in NFS....!"
   echo " " >> $logfile
   echo -e "Get list of images in NFS....!" >> $logfile
   echo 'Passing sessionid of first API to third curl request to get list of images from NFS server: ' $sessionid >> $logfile 
   echo 'Passing token of first API to third curl request to get list of images from NFS Server: ' $token >> $logfile 


   curl --insecure --silent --location --request GET . escapeshellarg "https://$n/api/settings/media/remote/images" --header "X-CSRFTOKEN: ${token//[$'\t\r\n ']}" --header 'Cache-Control: no-cache' --header "Cookie: QSESSIONID=${sessionid//[$'\t\r\n ']}" > isolist 

   cat isolist >> $logfile

   imagetype=`jq -r . isolist | jq '.[] | select(.image_name=="Win_Server_STD_DC_2019.iso")' | jq -r '.image_type'`

   echo " " >> $logfile
   echo -e 'image Type:' $imagetype >> $logfile

   imageindex=`jq -r . isolist | jq '.[] | select(.image_name=="Win_Server_STD_DC_2019.iso")' | jq -r '.image_index'`

   echo -e 'image index: '  $imageindex >> $logfile

#we are setting BIOS Boot Order in below curl request
#echo "Set one time Boot Order in BIOS....!"
   echo -e "Set one time Boot Order in BIOS....!" >>  $logfile

   curl  --insecure --silent --location --request PATCH "https://$n/redfish/v1/Systems/Self" --header 'Content-Type: application/json' --header 'Authorization: Basic YWRtaW46YmxhZGVydW5uZXI=' --data '{"Boot": {"BootSourceOverrideEnabled": "Once","BootSourceOverrideTarget": "Usb","BootSourceOverrideMode": "UEFI"}}' >>  $logfile

#we are now attaching media in BMC with respective ISO image
#echo "Attach Media in BMC....!"
   echo -e "Attach Media in BMC....!" >>  $logfile
   echo 'Passing sessionid of first API to fifth curl request to start Media in BMC with respective ISO: ' $sessionid >> $logfile 
   echo 'Passing token of first API to fifth curl request to start media in BMC with respective ISO: ' $token >> $logfile 


   curl --insecure --silent --location --request POST "https://$n/api/settings/media/remote/start-media" --header "X-CSRFTOKEN: ${token//[$'\t\r\n ']}" --header 'Cache-Control: no-cache' --header 'content-type: application/json' --header "Cookie: QSESSIONID=${sessionid//[$'\t\r\n ']}" --data '{"image_name":"Win_Server_STD_DC_2019.iso","image_type":'$imagetype',"image_index":'$imageindex'}' >> $logfile

#After attaching media in BMC console we are reset the console in below curl request
#echo -e "RESET BMC CONSOLE.......!"
   echo " " >> $logfile
   echo -e 'RESET BMC CONSOLE.......!' >> $logfile
   echo 'Passing sessionid of first API to sixth curl request: ' $sessionid >> $logfile


   curl --insecure --silent --location --request POST "https://$n/redfish/v1/Chassis/Self/Actions/Chassis.Reset" --header 'Content-Type: application/json' --header 'Authorization: Basic YWRtaW46YmxhZGVydW5uZXI=' --header "Cookie: QSESSIONID=${sessionid//[$'\t\r\n ']}" --data '{"ResetType": "ForceRestart"}' >> $logfile


#echo -e "OS installtion completed for $n"
   echo -e "OS installtion completed for $n" >>$logfile
   echo '' >>$logfile
done
